export default {
    experiences: {},
    projects:    {},
    educations:  {},
}