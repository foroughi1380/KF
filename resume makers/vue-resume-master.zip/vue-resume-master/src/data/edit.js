export default {
    experiences: null,
    projects:    null,
    educations:  null,
}