export default [
    { value: null, text: 'Please select the Level' },
    { value: 'Beginner', text: 'Beginner' },
    { value: 'Intermediate', text: 'Intermediate' },
    { value: 'Expert', text: 'Expert' },
]