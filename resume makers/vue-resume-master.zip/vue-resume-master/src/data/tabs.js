export default {
    index: 1,
    hasCurrentJob: false
}