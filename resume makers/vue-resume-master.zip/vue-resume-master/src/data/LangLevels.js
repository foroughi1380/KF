export default [
    { value: null, text: 'Please select the Level' },
    { value: 'Beginner', text: 'Beginner' },
    { value: 'Conversational ', text: 'Conversational ' },
    { value: 'Business ', text: 'Business ' },
    { value: 'Fluent', text: 'Fluent' },
]