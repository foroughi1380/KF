export default [
    { value: null, text: 'Please select an social media'},
    { value: 'linkedin-in', text: 'LinkedIn', url: 'https://www.linkedin.com/in/'},
    { value: 'facebook', text: 'Facebook', url: 'https://www.facebook.com/'},
    { value: 'instagram', text: 'Instagram', url: 'https://www.instagram.com/'},
    { value: 'instagram', text: 'Instagram', url: 'https://www.instagram.com/'},
    { value: 'github', text: 'Github', url: 'https://www.github.com/'},
    { value: 'behance', text: 'Behance', url: 'https://www.Behance.com/'},
    { value: 'dribbble', text: 'Dribbble', url: 'https://dribbble.com/'},
    { value: 'twitter', text: 'Twitter', url: 'https://www.Twitter.com/'},
    //todo: add more social networks
];