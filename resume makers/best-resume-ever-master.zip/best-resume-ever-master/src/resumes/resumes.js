// If you create a new resume, import it here:
import './material-dark.vue';
import './left-right.vue';
import './oblique.vue';
import './side-bar.vue';
import './purple.vue';
import './side-bar-rtl.vue';
import './left-right-rtl.vue';
import './oblique-rtl.vue';
import './creative.vue';
import './cool.vue';
import './cool-rtl.vue';
import './cool-rtl2.vue';
import './green.vue';
import './left-right-projects.vue';
import './material-dark-projects.vue';
import './oblique-projects.vue';
import './side-bar-projects.vue';
