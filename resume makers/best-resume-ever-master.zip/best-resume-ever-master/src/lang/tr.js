const lang = {
    contact: 'İletişim',
    experience: 'Deneyim',
    education: 'Eğitim',
    skills: 'Yetenekler',
    about: 'Hakkımda'
};
export default lang;
