// Spanish
const lang = {
    contact: 'Contacto',
    born: 'Nacido en',
    bornIn: 'en',
    experience: 'Experiencia',
    education: 'Educación',
    skills: 'Habilidades',
    projects: 'Proyectos',
    contributions: 'Contribuciones',
    about: 'Sobre mí'
};
export default lang;
