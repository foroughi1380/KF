const lang = {
    contact: 'Kontaktai',
    experience: 'Patirtis',
    education: 'Išsilavinimas',
    skills: 'Įgūdžiai',
    about: 'Apie mane'
};
export default lang;
