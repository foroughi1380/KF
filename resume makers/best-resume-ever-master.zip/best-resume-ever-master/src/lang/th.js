const lang = {
    contact: 'ข้อมูลติดต่อ',
    experience: 'ประสบการณ์ทำงาน',
    education: 'ประวัติการศึกษา',
    skills: 'ทักษะและความสามารถ',
    about: 'ข้อมูลส่วนตัว'
};
export default lang;
