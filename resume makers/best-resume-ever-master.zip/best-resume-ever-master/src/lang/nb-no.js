// Norwegian
const lang = {
    contact: 'Kontakt',
    born: 'Født',
    bornIn: 'i',
    experience: 'Arbeidserfaring',
    education: 'Utdannelse',
    skills: 'Ferdigheter',
    projects: 'Prosjekter',
    contributions: 'Bidrag',
    about: 'Om meg'
};
export default lang;