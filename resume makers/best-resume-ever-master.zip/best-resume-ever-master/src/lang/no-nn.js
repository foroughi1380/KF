// NO-NN
const lang = {
    contact: 'Kontakt',
    born: 'Fødd',
    bornIn: 'i',
    experience: 'Erfaring',
    education: 'Utdanning',
    skills: 'Ting eg kan',
    projects: 'Prosjekt',
    contributions: 'Bidrag',
    about: 'Om meg'
};
export default lang;
