const lang = {
    contact: 'კონტაქტი',
    experience: 'გამოცდილება',
    education: 'განათლება',
    skills: 'უნარები',
    about: 'ჩემ შესახებ'
};
export default lang;
