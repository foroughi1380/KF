# CVue-Awesome

[![Netlify Status](https://api.netlify.com/api/v1/badges/9b956c21-a367-4dfc-92b0-7bd7b9a6e1b4/deploy-status)](https://app.netlify.com/sites/emrec/deploys)

## [Demo](https://emrec.netlify.app/)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

# ToDo List

- [ ] Dark Theme Support
- [ ] Language Support
- [ ] Different Theme 
- [ ] Get Data from Linkedin, PDF etc.
